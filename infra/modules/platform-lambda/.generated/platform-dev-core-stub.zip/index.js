"use strict";

exports.handler = async () => ({
  statusCode: 200,
  headers: { "content-type": "application/json" },
  body: JSON.stringify({
    message: "Clarivum runtime placeholder",
    timestamp: new Date().toISOString()
  })
});
